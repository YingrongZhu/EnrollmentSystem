import React from 'react'
import ReactDOM from 'react-dom'
import axios from 'axios';

class GetMember extends React.Component{
    constructor(props){
        super(props);
        this.state = { name: "a",age:-1,searchName:"",addName:"",addAge:-1 };
        // this.toggleFinished = this.toggleFinished.bind(this);
        // this.onToggleLoop = this.onToggleLoop.bind(this)
        this.goGet = this.goGet.bind(this); 
        this.handleChange = this.handleChange.bind(this);
        this.addAge = this.addAge.bind(this);
        this.addName = this.addName.bind(this);
        this.addMem = this.addMem.bind(this); 
        // this.searchName=""
    }
    
    handleChange(event){
        this.setState({searchName: event.target.value});
    }

    addName(event){
        this.setState({addName: event.target.value});
    }

    addAge(event){
        this.setState({addAge: event.target.value});
    }

    goGet(){
        axios.get(`http://127.0.0.1:8080/getMember/getOne/${this.state.searchName}`)
        .then((resp)=>{
            if(resp.status===200){
                resp.data.map((x)=>{
                    this.setState({
                        name: x.name,
                        age:x.age
                    });
                    return 0;
                })
            }else if(resp.status===250){
                alert("not found")
            }else{
                alert("something wrong")
            }

        })
        .catch((err)=>{
            alert("error:  "+err)
            console.log("error: "+err)
        });
    }

    addMem(){
        if(this.state.addAge>0&&this.state.addAge<150&&this.state.addName.length>0){
            axios.post(`http://127.0.0.1:8080/api/addMember`,
            {name:`${this.state.addName}`,age:this.state.addAge})
            .then((resp)=>{
                if(resp.status===200){
                    alert('add succeeded')
                }else if(resp.status===250){
                    alert('add failed')
                }else{
                    alert('something wrong')
                }
            })
            .catch((err)=>{
                alert(err)
            })
        }else{
            alert("invalid input")
        }
    }

    render(){
        return(
            <div>
                <dl>
                    <dd><input type="text" value={this.state.searchName} onChange={this.handleChange}/></dd>
                    <dd><button onClick={this.goGet}>Get one member</button></dd>
                </dl>
                <dl>
                    <dt>Name</dt>
                    <dd>{this.state.name}</dd>

                    <dt>Age</dt>
                    <dd>{this.state.age}</dd>
                </dl>

                <dl>
                    <dd><input type="text" value={this.state.addName} onChange={this.addName}/></dd>
                    <dd><input type="text" value={this.state.addAge} onChange={this.addAge}/></dd>
                    <dd><button onClick={this.addMem}>Add one member</button></dd>
                </dl>
            </div>
        )
    }
}

ReactDOM.render(
    <GetMember />,
    document.getElementById('getMember')
);