import React from 'react'
import ReactDOM from 'react-dom'
import CallBetween from "./CallBetween"

var c=0
var cntStyle={
    fontSize:20,
    color:'#0000FF'

}
function Display(){
    return(
        <div align="center" style={cntStyle}>
            <h1>This is called from HTML to JS 123456</h1>
            <div>
                <button onClick={add}> +1</button>
                <h1>Cnt is {c}</h1>
            </div>
        </div>
    );
}

function add(){
    c++;
    ReactDOM.render(<Display/>, document.getElementById('call'));
    ReactDOM.render(<CallBetween num={c}/>, document.getElementById('between'));
}

ReactDOM.render(<Display/>, document.getElementById('call'));

export default Display;