import React from 'react'
import ReactDOM from 'react-dom';

function Clock(){
    return(
        <h1 align="center">
            {new Date().toLocaleTimeString()}
            {/* <button onClick={add()}>+1</button>
            <div>Cnt is {cnt}</div> */}
        </h1>
    )
}

function tk(){
    ReactDOM.render(<Clock/>, document.getElementById('clock'));
}


export default tk;