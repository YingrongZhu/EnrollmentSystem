import React from 'react';
import ReactDOM from 'react-dom';

function CallBetween(props){
    return(
        <div>
            <h1>
                this is {props.num}
            </h1>
        </div>
    );
}

export default CallBetween;