import React from 'react'
import ReactDOM from 'react-dom'


const st = {
    fontSize:20,color:'#FF0000'
}
function MakeList(props){
    const list=props.list;
    const listItem = list.map((item)=>
        <dd key={item.toString()}>&middot;
            {item}
        </dd>
    );

    return(
        <div align="center">
            <dt style={st}>This is a dl dt dd List</dt>
            <dl>
                {listItem}
            </dl>
        </div>
    );
}

ReactDOM.render(
    <MakeList list={["isjdjn","asd54",513132]} />,
    document.getElementById('list')
  );