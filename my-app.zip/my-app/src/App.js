import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header"> */}
        <img src="https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1208099638,2005282168&fm=26&gp=0.jpg" className="App-logo" alt="logo" />
        <br/>
        <a
          className="App-link"
          href="https://www.google.com/search?q=husky"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn Husky
        </a>
        <a href="http://www.baidu.com">
          <button>Button</button>
        </a>
      {/* </header> */}
    </div>
  );
}

export default App;
