import React from 'react'
import ReactDOM from 'react-dom'
class LoginControl extends React.Component {
    constructor(props) {
      super(props);
      this.handleLoginClick = this.handleLoginClick.bind(this);
      this.handleLogoutClick = this.handleLogoutClick.bind(this);
      this.state = {isLoggedIn: false};
      this.firstIn = false;
    }
   
    handleLoginClick() {
      this.setState({isLoggedIn: true});
    }
   
    handleLogoutClick() {
      this.setState({isLoggedIn: false});
    }
   
    render() {
      const isLoggedIn = this.state.isLoggedIn;
   
      let button = null;
      if (isLoggedIn) {
        button = <button onClick={this.handleLogoutClick}>logout</button>;
      } else {
        button = <button onClick={this.handleLoginClick}>login</button>;
      }
   
      return (
        <div>
          {/* <Greeting isLoggedIn={isLoggedIn} /> */}
          {button}
            {this.firstIn && alert(isLoggedIn)}
            {this.firstIn=true}
        </div>
      );
    }
  }
   
  ReactDOM.render(
    <LoginControl />,
    document.getElementById('condition')
  );