const Member =require('./schema/member')
const express = require('express');
var app = express();
var bodyParser = require('body-parser');
var url = "mongodb://localhost:27017/test";
var cors = require('cors');
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var port = process.env.PORT || 8080;        // 设置端口

var swig = require('swig');
app.engine('html',swig.renderFile);   //定义模版引擎，第一个参数是模版引擎名称，同时也是模版文件的后缀，使用swig.renderFile方法解析后缀威html的文件
app.set('views','./views');  //设置模版存放目录，第一个参数必须是views,第二个参数是目录
app.set('view engine','html');   //注册模版引擎,第一个参数必须是view engine,第二个参数和app.engine中定义的模版引擎的名称是一致的(第一个参数)
swig.setDefaults({cache: false});   //在开发过程中，需要取消模版默认缓存

var router = express.Router(); 

app.use('/api', router);//register this router
router.get('/', function(req, res) {
    res.json({ message: 'express.use router -> router.get' });   
});

app.use('/main',require("./mid"),require("./main"));

router.route('/abc')
    .get(function(req,res){
        res.json({message:"router.route.get"});
    })

app.use('/getMember',require('./getMember'));

const mongoose = require('mongoose');
mongoose.connect(url,{ useNewUrlParser: true,useCreateIndex:true,useUnifiedTopology:true });
mongoose.connection.once('open', function(err){
    if(err){
        console.log("error: "+err)
    }else{
        console.log('mongo connected')
    }
})

app.listen(port,function () {
    console.log("server started at port: "+port)
})

router.route('/addMember')
    .post(function(req,res){
        var member=new Member();
        member.name=req.body.name;
        member.age=req.body.age;
        member.save(function(err){
            if(err){
                res.status(250).json({message:'error'})
                console.log('error: '+err)
            }else{
                res.status(200).json({message:"member created",member})
            }
        });
    })