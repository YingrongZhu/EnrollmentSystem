const Member =require('./schema/member')
const express = require('express');

const router= express.Router();

router.get('/getOne/:name',function(req,res){
    Member.find({'name':req.params.name},function(err,member) {
        if(err){
            console.log("error:  "+err);
            res.json({'message':'error'})
        }else{
            if(member.length>0){
                res.status(200).json(member);
            }else{
                res.status(250).json(member)
            }
        }
    });
});

router.get('/update',function(req,res){
    Member.findOneAndUpdate({name:'Tom'},{name:'Joy'},(err,doc)=>{
        if(err){
            res.status(500).json({message:'error'})
            console.log('error: '+err)
        }else{
            res.status(200).json({message:"member updated"})
        }
    });
})

module.exports=router;